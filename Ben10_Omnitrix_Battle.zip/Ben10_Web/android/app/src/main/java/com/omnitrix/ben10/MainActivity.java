package com.omnitrix.ben10;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
