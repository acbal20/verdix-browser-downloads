/* ============================================================
   BEN 10 · OMNITRIX BATTLE 3D
   Interfaz, tienda, HUD, controles, menú de modos,
   historia, ranking global, perfil, autenticación y amigos
   ============================================================ */

const UI = (function () {
  const D = {};
  let shopTab = 'upgrades';
  let shopFrom = 'menu';
  let toastTimer = null, bannerTimer = null, hurtTimer = null;
  let hudT = 0;
  let hoverAt = 0;

  function cache() {
    const ids = [
      'game', 'hud', 'hpFill', 'hpText', 'omniFill', 'omniText', 'waveVal', 'enemyVal',
      'coinVal', 'gemVal', 'muteBtn', 'pauseBtn', 'bossBar', 'bossFill', 'combo', 'powerRow',
      'alienBar', 'banner', 'bannerTitle', 'bannerSub', 'toast', 'menu', 'menuCoins', 'menuGems',
      'menuMuteBtn', 'startBtn', 'shopBtn', 'helpBtn', 'bestVal', 'bestWaveVal',
      'shop', 'shopCoins', 'shopGems', 'shopClose', 'shopGrid', 'help', 'helpClose',
      'pause', 'resumeBtn', 'pauseShopBtn', 'quitBtn',
      'over', 'overTag', 'overTitle', 'overMsg', 'overWave', 'overScore', 'overBest',
      'runCoins', 'runGems', 'retryBtn', 'overShopBtn', 'menuBtn',
      'stick', 'knob', 'btnA', 'btnB', 'btnDash', 'boot', 'hurtFlash', 'damageFlash',
      // nuevos overlays
      'btnStory', 'btnFree', 'btnRanking', 'btnOptions', 'profileBar', 'profileName',
      'btnChangeName', 'playerNameInput', 'btnSaveName', 'btnCancelName', 'profileMsg',
      'storyScreen', 'storyLevels', 'btnBackStory', 'rankingScreen', 'rankingList',
      'rankingStatus', 'btnRefreshRanking', 'btnBackRanking', 'optionsScreen',
      'optMuteBtn', 'optQualityBtn', 'optGodBtn', 'adminPanel', 'adminList',
      'adminNameInput', 'btnAddMod', 'btnBackAdmin', 'btnBackOptions', 'godIndicator',
      'lvlVal', 'scoreVal',
      // auth
      'authScreen', 'loginForm', 'registerForm', 'loginUsername', 'loginPassword',
      'registerUsername', 'registerPassword', 'registerConfirm', 'btnLogin',
      'btnRegister', 'btnShowRegister', 'btnShowLogin', 'authMsg', 'btnLogout',
      'btnFriends', 'friendsScreen', 'friendsList', 'friendNameInput', 'btnAddFriend',
      'btnBackFriends', 'btnBackAuth',
      // controles táctiles
      'btnControls', 'controlsScreen', 'controlsPreview', 'ctrlStickSize', 'ctrlBtnSize',
      'ctrlScale', 'ctrlLayoutLeft', 'ctrlLayoutRight', 'btnResetControls', 'btnSaveControls',
      'btnBackControls',
      // tienda de personajes
      'btnCharStore', 'charStoreScreen', 'charStore', 'btnBackCharStore',
      // diálogo NPC
      'npcDialog', 'npcName', 'npcText'
    ];
    ids.forEach(id => D[id] = document.getElementById(id));
  }

  function show(id) { const el = D[id] || document.getElementById(id); if (el) el.classList.remove('hidden'); }
  function hide(id) { const el = D[id] || document.getElementById(id); if (el) el.classList.add('hidden'); }
  function showGodIndicator(on) {
    if (!D.godIndicator) return;
    D.godIndicator.classList.toggle('hidden', !on);
  }

  function toast(msg) {
    if (!D.toast) return;
    D.toast.textContent = msg;
    D.toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => D.toast.classList.remove('show'), 2200);
  }

  function banner(title, sub, dur) {
    if (!D.banner) return;
    D.bannerTitle.textContent = title;
    D.bannerSub.textContent = sub || '';
    D.banner.classList.add('show');
    clearTimeout(bannerTimer);
    bannerTimer = setTimeout(() => D.banner.classList.remove('show'), (dur || 2.2) * 1000);
  }

  function hurtFlash() {
    if (!D.hurtFlash) return;
    D.hurtFlash.classList.add('flash');
    clearTimeout(hurtTimer);
    hurtTimer = setTimeout(() => D.hurtFlash.classList.remove('flash'), 120);
  }

  function screenFlash(color) {
    const el = D.damageFlash || document.getElementById('damageFlash');
    if (!el) return;
    el.style.background = color ?
      'radial-gradient(circle at center,rgba(255,255,255,0) 40%,' + color + ' 100%)' : '';
    el.style.opacity = color ? 0.85 : 0;
    clearTimeout(window._damageFlashTmr);
    window._damageFlashTmr = setTimeout(() => { el.style.opacity = 0; }, 140);
  }

  function wallet() {
    const c = SAVE.coins | 0, g = SAVE.gems | 0;
    if (D.menuCoins) D.menuCoins.textContent = c;
    if (D.menuGems) D.menuGems.textContent = g;
    if (D.shopCoins) D.shopCoins.textContent = c;
    if (D.shopGems) D.shopGems.textContent = g;
    if (D.coinVal) D.coinVal.textContent = c;
    if (D.gemVal) D.gemVal.textContent = g;
  }

  function menuStats() {
    if (D.bestVal) D.bestVal.textContent = SAVE.best | 0;
    if (D.bestWaveVal) D.bestWaveVal.textContent = SAVE.bestWave | 0;
    wallet();
  }

  function updateMute() {
    const t = AudioEngine.isMuted() ? '🔇' : '🔊';
    if (D.muteBtn) { D.muteBtn.textContent = t; D.muteBtn.title = AudioEngine.isMuted() ? 'Activar sonido' : 'Silenciar'; }
    if (D.menuMuteBtn) { D.menuMuteBtn.textContent = t; D.menuMuteBtn.title = D.muteBtn.title; }
    if (D.optMuteBtn) D.optMuteBtn.textContent = AudioEngine.isMuted() ? '🔇 Silenciado' : '🔊 Activado';
  }

  function toggleMute() {
    AudioEngine.toggleMuted();
    updateMute();
    if (!AudioEngine.isMuted()) AudioEngine.sfx('click');
    toast(AudioEngine.isMuted() ? '🔇 Sonido silenciado' : '🔊 Sonido activado');
  }

  function combo(n) {
    if (!D.combo) return;
    if (n >= 2) {
      D.combo.innerHTML = 'x' + n + ' <small>COMBO</small>';
      D.combo.classList.remove('hidden');
    } else {
      D.combo.classList.add('hidden');
    }
  }

  function boss(on) {
    if (!D.bossBar) return;
    D.bossBar.classList.toggle('hidden', !on);
  }

  function powerBadges() {
    if (!D.powerRow || !P) return;
    const defs = [
      ['shieldT', '🛡️', 'Escudo'],
      ['rapidT', '⚡', 'Furia'],
      ['magnetT', '🧲', 'Imán'],
      ['x2T', '💰', 'x2'],
      ['rageT', '🔥', 'Rabia']
    ];
    let html = '';
    for (const [key, ico, name] of defs) {
      if (P[key] > 0) html += '<span class="powerBadge">' + ico + ' ' + name + ' ' + Math.ceil(P[key]) + 's</span>';
    }
    D.powerRow.innerHTML = html;
  }

  function refresh() {
    if (!P || !D.hpFill) return;
    const hpPct = clamp(P.hp / Math.max(1, P.maxHp), 0, 1) * 100;
    D.hpFill.style.width = hpPct + '%';
    D.hpText.textContent = Math.ceil(P.hp) + '/' + Math.round(P.maxHp);
    const omPct = clamp(G.omni / Math.max(1, omniMaxOf()), 0, 1) * 100;
    D.omniFill.style.width = omPct + '%';
    D.omniText.textContent = Math.round(G.omni) + '/' + Math.round(omniMaxOf());

    if (D.waveVal) D.waveVal.textContent = G.wave || 1;
    if (D.lvlVal) D.lvlVal.textContent = (G.storyLevel || 1);
    if (D.scoreVal) D.scoreVal.textContent = G.score;

    if (D.enemyVal) {
      if (G.between) {
        D.enemyVal.textContent = 'Próxima en ' + Math.max(0, Math.ceil(G.breakT)) + 's';
      } else {
        let left = G.spawnQueue.length;
        for (const e of G.enemies) if (!e.dead) left++;
        D.enemyVal.textContent = left + (left === 1 ? ' enemigo' : ' enemigos');
      }
    }

    if (D.coinVal) D.coinVal.textContent = SAVE.coins | 0;
    if (D.gemVal) D.gemVal.textContent = SAVE.gems | 0;

    if (G.boss && !G.boss.dead && D.bossFill) {
      boss(true);
      D.bossFill.style.width = clamp(G.boss.hp / G.boss.maxHp, 0, 1) * 100 + '%';
    } else if (!G.boss) {
      boss(false);
    }

    powerBadges();

    if (D.alienBar) {
      const cards = D.alienBar.querySelectorAll('.alienCard');
      cards.forEach(card => {
        const id = card.dataset.form;
        const unlocked = isUnlocked(id);
        card.classList.toggle('locked', !unlocked);
        card.classList.toggle('active', unlocked && P.form === id);
        const lock = card.querySelector('.lock');
        if (lock) lock.style.display = unlocked ? 'none' : 'block';
      });
    }
  }

  function updateStoryHUD() {
    const el = document.getElementById('storyGoalBar');
    if (!el) return;
    if (G.mode === 'story' && G.storyGoal) {
      el.classList.remove('hidden');
      const pct = clamp(G.storyGoal.current / Math.max(1, G.storyGoal.target), 0, 1) * 100;
      el.innerHTML = '<div style="font-size:9px;color:#7dffb8;letter-spacing:.1em">' + G.storyGoal.label + '</div>' +
        '<div style="height:6px;background:rgba(255,255,255,.08);border-radius:3px;overflow:hidden;margin-top:4px">' +
        '<div style="height:100%;width:' + pct + '%;background:#7dffb8;box-shadow:0 0 12px rgba(90,255,160,.6)"></div></div>' +
        '<div style="font-size:10px;color:#c9ffe0;margin-top:3px">' + G.storyGoal.current + '/' + G.storyGoal.target + '</div>';
    } else {
      el.classList.add('hidden');
    }
  }

  function setPlaying(on) {
    if (!D.hud) return;
    D.hud.classList.toggle('hidden', !on);
    document.body.classList.toggle('playing', on);
    if (!on) {
      boss(false);
      combo(0);
      if (D.powerRow) D.powerRow.innerHTML = '';
    }
  }

  function alienCards() {
    if (!D.alienBar) return;
    if (!D.alienBar.children.length) {
      ALIEN_ORDER.forEach(a => {
        const f = FORMS[a.id];
        const b = document.createElement('button');
        b.className = 'alienCard';
        b.dataset.form = a.id;
        b.innerHTML =
          '<span class="key">' + a.key + '</span>' +
          '<span class="ico">' + f.icon + '</span>' +
          '<span class="nm">' + f.name + '</span>' +
          '<span class="lock">🔒</span>';
        b.addEventListener('click', () => {
          if (!isUnlocked(a.id)) {
            AudioEngine.sfx('error');
            toast('🔒 ' + f.name + ' se desbloquea en la tienda');
            return;
          }
          transformTo(a.id);
        });
        D.alienBar.appendChild(b);
      });
    }
    refresh();
  }

  /* ==================== Autenticación ==================== */
  function loadProfile() {
    const name = SAVE.playerName || getCurrentUser() || '';
    if (D.profileName) D.profileName.textContent = name || 'Sin nombre';
    if (D.profileBar) D.profileBar.classList.toggle('hidden', !name);
    if (D.btnLogout) D.btnLogout.classList.toggle('hidden', !name);
  }

  function openAuth() {
    hide('menu');
    if (D.authScreen) D.authScreen.classList.remove('hidden');
    showAuthForm('login');
    if (D.authMsg) { D.authMsg.textContent = ''; D.authMsg.classList.add('hidden'); }
    if (D.loginUsername) D.loginUsername.focus();
  }

  function showAuthForm(form) {
    if (D.loginForm) D.loginForm.classList.add('hidden');
    if (D.registerForm) D.registerForm.classList.add('hidden');
    if (form === 'login') {
      if (D.loginForm) D.loginForm.classList.remove('hidden');
    } else {
      if (D.registerForm) D.registerForm.classList.remove('hidden');
    }
  }

  function doLogin() {
    const user = D.loginUsername ? D.loginUsername.value.trim() : '';
    const pass = D.loginPassword ? D.loginPassword.value : '';
    if (!user || !pass) { showAuthMsg('Ingresá usuario y contraseña', 'error'); return; }
    const res = loginUser(user, pass);
    if (res.ok) {
      toast('✅ Sesión iniciada: ' + user);
      hide('authScreen');
      loadProfile();
      show('menu');
      UI.updateMenuAdmin();
    } else {
      showAuthMsg(res.msg, 'error');
    }
  }

  function doRegister() {
    const user = D.registerUsername ? D.registerUsername.value.trim() : '';
    const pass = D.registerPassword ? D.registerPassword.value : '';
    const confirm = D.registerConfirm ? D.registerConfirm.value : '';
    if (!user || !pass || !confirm) { showAuthMsg('Completá todos los campos', 'error'); return; }
    if (pass !== confirm) { showAuthMsg('Las contraseñas no coinciden', 'error'); return; }
    const res = registerUser(user, pass);
    if (res.ok) {
      toast('✅ Usuario registrado: ' + user);
      showAuthForm('login');
      if (D.loginUsername) D.loginUsername.value = user;
      if (D.loginPassword) D.loginPassword.value = '';
    } else {
      showAuthMsg(res.msg, 'error');
    }
  }

  function showAuthMsg(msg, type) {
    if (!D.authMsg) return;
    D.authMsg.textContent = msg;
    D.authMsg.className = 'authMsg ' + (type === 'error' ? 'error' : 'success');
    D.authMsg.classList.remove('hidden');
    D.authMsg.style.color = type === 'error' ? '#ff6b6b' : '#63ff96';
  }

  function doLogout() {
    logoutUser();
    loadProfile();
    toast('👋 Sesión cerrada');
    if (P) { quitToMenu(); }
  }

  function updateMenuAdmin() {
    const name = getCurrentUser() || SAVE.playerName || '';
    const isAdm = SAVE.admin || name === 'acbal20' || (USERS[name] && USERS[name].admin);
    if (D.optGodBtn) D.optGodBtn.classList.toggle('hidden', !isAdm);
    if (D.profileBar) {
      if (name) {
        D.profileName.textContent = name + (isAdm ? ' 👑' : '');
      }
    }
  }

  /* ==================== Modo Historia ==================== */
  function renderStoryLevels() {
    if (!D.storyLevels) return;
    const progress = getStoryProgress();
    let html = '';
    STORY_LEVELS.forEach(lvl => {
      const unlocked = isStoryLevelUnlocked(lvl.id);
      const done = lvl.id <= progress;
      const cls = done ? 'done' : (unlocked ? 'open' : 'locked');
      html += '<div class="storyCard ' + cls + '">' +
        '<div class="head"><span class="lvlNum">' + lvl.id + '</span>' +
        (done ? '<span class="lvlLock">✅</span>' : !unlocked ? '<span class="lvlLock">🔒</span>' : '') + '</div>' +
        '<h4>' + lvl.name + '</h4>' +
        '<p>' + lvl.goal.label + '</p>' +
        '<div class="status ' + (done ? 'done' : !unlocked ? 'locked' : 'open') + '">' +
        (done ? 'COMPLETADO' : !unlocked ? 'BLOQUEADO' : 'DISPONIBLE') + '</div>' +
        '</div>';
    });
    D.storyLevels.innerHTML = html;

    D.storyLevels.querySelectorAll('.storyCard').forEach((card, idx) => {
      const lvl = STORY_LEVELS[idx];
      card.addEventListener('click', () => {
        if (!isStoryLevelUnlocked(lvl.id)) {
          AudioEngine.sfx('error');
          toast('🔒 Nivel bloqueado. Completá el anterior.');
          return;
        }
        AudioEngine.sfx('click');
        G.mode = 'story';
        G.storyLevel = lvl.id;
        G.storyGoal = null;
        hide('storyScreen');
        startRun();
      });
    });
  }

  function openStory() {
    hide('menu');
    renderStoryLevels();
    show('storyScreen');
  }

  /* ==================== Ranking Global ==================== */
  window.moderatorsSet = new Set();

  function renderRanking(scores) {
    if (!D.rankingList) return;
    if (!scores || scores.length === 0) {
      D.rankingList.innerHTML = '<div class="rankingRow placeholder">Sin puntajes aún. ¡Sé el primero!</div>';
      return;
    }
    let html = '';
    const name = getCurrentUser() || SAVE.playerName || '';
    scores.forEach((s, i) => {
      const pos = i + 1;
      const isMe = s.name === name;
      const isMod = window.moderatorsSet.has(s.name);
      html += '<div class="rankingRow ' + (isMe ? 'me' : '') + ' ' + (isMod ? 'mod' : '') + '">' +
        '<span class="pos">' + pos + '</span>' +
        '<span class="name">' + escapeHtml(s.name) + '</span>' +
        '<span class="score">' + s.score.toLocaleString('es-AR') + '</span>' +
        '</div>';
    });
    D.rankingList.innerHTML = html;
  }

  function escapeHtml(txt) {
    const d = document.createElement('div');
    d.textContent = txt;
    return d.innerHTML;
  }

  function loadRanking() {
    if (D.rankingStatus) {
      D.rankingStatus.classList.remove('hidden');
      D.rankingStatus.textContent = 'Conectando con Firebase…';
    }
    if (window.getFirebaseScores) {
      window.getFirebaseScores((scores) => {
        renderRanking(scores);
        if (D.rankingStatus) D.rankingStatus.classList.add('hidden');
      });
    } else {
      renderRanking([]);
      if (D.rankingStatus) D.rankingStatus.classList.add('hidden');
    }
  }

  function loadModerators() {
    if (!window.getFirebaseModerators) return;
    window.getFirebaseModerators((mods) => {
      window.moderatorsSet = new Set((mods || []).map(m => m.name));
      renderAdminList();
      const name = getCurrentUser() || SAVE.playerName || '';
      if (window.moderatorsSet.has(name)) {
        godModeActive = true;
        SAVE.godMode = true;
        SAVE.infiniteLife = true;
        saveUserData();
        if (P) { P.hp = 999999; P.maxHp = 999999; G.omni = 999999; UI.showGodIndicator(true); UI.refresh(); }
      }
    });
  }

  function renderAdminList() {
    if (!D.adminList) return;
    const mods = Array.from(window.moderatorsSet || []);
    if (mods.length === 0) {
      D.adminList.innerHTML = '<div class="adminItem">No hay moderadores aún</div>';
      return;
    }
    D.adminList.innerHTML = mods.map(m => {
      const isCreator = m === 'acbal20';
      return '<div class="adminItem">' +
        '<span class="modName">' + escapeHtml(m) + (isCreator ? ' (Creador/Admin)' : '') + '</span>' +
        (!isCreator ? '<span class="modRemove" onclick="removeMod(\'' + escapeHtml(m) + '\')">✕</span>' : '') +
        '</div>';
    }).join('');
  }

  window.addMod = function() {
    const input = D.adminNameInput;
    if (!input) return;
    const name = (input.value || '').trim();
    if (!name) return;
    if (window.addFirebaseModerator) {
      if (window.addFirebaseModerator(name)) {
        toast('✅ Moderador agregado: ' + name);
        input.value = '';
      } else {
        toast('❌ Error al agregar moderador');
      }
    }
  };
  window.removeMod = function(name) {
    if (window.removeFirebaseModerator) {
      if (window.removeFirebaseModerator(name)) {
        toast('✅ Moderador removido: ' + name);
        renderAdminList();
      } else {
        toast('❌ Error al remover moderador');
      }
    }
  };

  function openRanking() {
    hide('menu');
    loadRanking();
    show('rankingScreen');
  }

  /* ==================== Amigos ==================== */
  function openFriends() {
    hide('menu');
    renderFriendsList();
    show('friendsScreen');
  }

  function renderFriendsList() {
    if (!D.friendsList) return;
    const friends = loadFriends();
    if (friends.length === 0) {
      D.friendsList.innerHTML = '<div class="adminItem">No tenés amigos aún. Agregá tu primer amigo.</div>';
      return;
    }
    D.friendsList.innerHTML = friends.map(f => {
      const u = USERS[f] || {};
      return '<div class="adminItem">' +
        '<span class="modName">' + escapeHtml(f) + (u.admin ? ' 👑' : '') + '</span>' +
        '<span class="modRemove" onclick="removeFriendUI(\'' + escapeHtml(f) + '\')">✕</span>' +
        '</div>';
    }).join('');
  }

  window.removeFriendUI = function(name) {
    const res = removeFriend(name);
    if (res.ok) {
      toast(res.msg);
      renderFriendsList();
    } else {
      toast(res.msg);
    }
  };

  function doAddFriend() {
    const input = D.friendNameInput;
    if (!input) return;
    const name = (input.value || '').trim();
    if (!name) return;
    const res = addFriend(name);
    toast(res.msg);
    if (res.ok) {
      input.value = '';
      renderFriendsList();
    }
  }

  /* ==================== Opciones ==================== */
  function openOptions() {
    hide('menu');
    const name = getCurrentUser() || SAVE.playerName || '';
    const isAdm = SAVE.admin || name === 'acbal20' || (USERS[name] && USERS[name].admin);
    if (D.optGodBtn) D.optGodBtn.classList.toggle('hidden', !isAdm);
    show('optionsScreen');
  }

  function openAdmin() {
    hide('optionsScreen');
    loadModerators();
    show('adminPanel');
  }

  /* ==================== Tienda ==================== */
  function card(inner, cls) {
    return '<div class="shopCard ' + (cls || '') + '">' + inner + '</div>';
  }

  function renderShop() {
    if (!D.shopGrid) return;
    wallet();
    document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === shopTab));

    if (shopTab === 'drops') {
      const chance = dropChances();
      const luck = SAVE.up.luck | 0;
      let html = '<div class="dropNote">Probabilidad por enemigo derrotado · Suerte nivel ' + luck + ' (+' + (luck * 12) + '%)</div>';
      chance.forEach(d => {
        html += '<div class="dropRow">' +
          '<div style="flex:1"><div class="dl">' + d.icon + ' ' + d.label + '</div>' +
          '<div class="dropBar"><i style="width:' + Math.min(100, d.pct * 1.9) + '%"></i></div></div>' +
          '<div class="dv">' + d.pct.toFixed(1) + '%</div>' +
          '</div>';
      });
      html += '<div class="dropNote">Potenciadores: ' + POWERS.map(p => p.icon + ' ' + p.name).join(' · ') + '</div>';
      html += '<div class="dropNote">Los jefes garantizan 1💎 + monedas + vida + potenciador.</div>';
      D.shopGrid.innerHTML = html;
      return;
    }

    if (shopTab === 'upgrades') {
      D.shopGrid.innerHTML = SHOP.upgrades.map(u => {
        const lvl = SAVE.up[u.id] | 0;
        const maxed = lvl >= u.max;
        const cost = upgradeCost(u);
        let dots = '';
        for (let i = 0; i < u.max; i++) dots += '<i class="' + (i < lvl ? 'on' : '') + '"></i>';
        const price = maxed
          ? '<button class="priceBtn off">MÁXIMO</button>'
          : '<button class="priceBtn ' + (u.cur === 'gems' ? 'gem' : '') + '" data-buy="upgrade:' + u.id + '">' + priceLabel(cost, u.cur) + '</button>';
        return card(
          '<div class="head"><span class="ico">' + u.icon + '</span><h4>' + u.name + '</h4></div>' +
          '<p>' + u.desc + '</p>' +
          '<div class="lvlDots">' + dots + '</div>' + price,
          maxed ? 'max' : ''
        );
      }).join('');
    } else if (shopTab === 'aliens') {
      D.shopGrid.innerHTML = SHOP.aliens.map(a => {
        const owned = !!SAVE.aliens[a.id];
        const f = FORMS[a.id];
        const price = owned
          ? '<button class="priceBtn off">DESBLOQUEADO</button>'
          : '<button class="priceBtn ' + (a.cur === 'gems' ? 'gem' : '') + '" data-buy="alien:' + a.id + '">' + priceLabel(a.price, a.cur) + '</button>';
        return card(
          '<div class="head"><span class="ico">' + a.icon + '</span><h4>' + a.name + '</h4></div>' +
          '<p>' + a.desc + '</p>' +
          '<small class="stat">❤️ ' + (f.hp + (SAVE.up.hp | 0) * 20) + ' · 👟 ' + f.speed.toFixed(1) + ' · ' + f.icon + '</small>' +
          price,
          owned ? 'owned' : ''
        );
      }).join('');
    } else if (shopTab === 'modules') {
      let html = SHOP.modules.map(m => {
        const owned = !!SAVE.modules[m.id];
        const price = owned
          ? '<button class="priceBtn off">ACTIVO</button>'
          : '<button class="priceBtn ' + (m.cur === 'gems' ? 'gem' : '') + '" data-buy="module:' + m.id + '">' + priceLabel(m.price, m.cur) + '</button>';
        return card(
          '<div class="head"><span class="ico">' + m.icon + '</span><h4>' + m.name + '</h4></div>' +
          '<p>' + m.desc + '</p>' + price,
          owned ? 'owned' : ''
        );
      }).join('');

      html += SHOP.skins.map(s => {
        const owned = SAVE.skin === s.id;
        const price = owned
          ? '<button class="priceBtn off">EQUIPADO</button>'
          : '<button class="priceBtn ' + (s.cur === 'gems' ? 'gem' : '') + '" data-buy="skin:' + s.id + '">' + priceLabel(s.price, s.cur) + '</button>';
        return card(
          '<div class="head"><span class="ico">' + s.icon + '</span><h4>' + s.name + '</h4></div>' +
          '<p>' + s.desc + '</p>' + price,
          owned ? 'owned' : ''
        );
      }).join('');
      D.shopGrid.innerHTML = html;
    }
  }

  function handleBuy(kind, id) {
    const res = buyItem(kind, id);
    if (!res.ok) {
      AudioEngine.sfx('error');
      toast(res.msg);
      return;
    }
    AudioEngine.sfx('buy');
    if (P && kind === 'upgrade') {
      if (id === 'hp') {
        P.maxHp = maxHpOf(P.form);
        P.hp = Math.min(P.maxHp, P.hp + 20);
      } else if (id === 'omni') {
        G.omni = Math.min(omniMaxOf(), G.omni + 15);
      }
    }
    let name = '';
    if (kind === 'upgrade') name = (UPGRADE_BY_ID[id] || {}).name || '';
    if (kind === 'alien') name = (SHOP.aliens.find(a => a.id === id) || {}).name || '';
    if (kind === 'module') name = (SHOP.modules.find(a => a.id === id) || {}).name || '';
    if (kind === 'skin') name = (SHOP.skins.find(a => a.id === id) || {}).name || '';
    toast('✅ Compraste: ' + name);
    if (kind === 'alien') alienCards();
    if (kind === 'skin') {
      document.body.classList.toggle('gold', SAVE.skin === 'gold');
      if (P) setFormModel(P.form);
      if (D.muteBtn) wallet();
    }
    wallet();
    refresh();
    renderShop();
    menuStats();
    saveUserData();
  }

  function openShop(from) {
    shopFrom = from || 'menu';
    hide('menu'); hide('pause'); hide('over'); hide('help');
    if (G.state === 'playing') G.state = 'paused';
    renderShop();
    show('shop');
    wallet();
  }

  function closeShop() {
    hide('shop');
    if (shopFrom === 'menu') {
      G.state = 'menu';
      show('menu');
      menuStats();
    } else if (shopFrom === 'pause') {
      show('pause');
    } else if (shopFrom === 'over') {
      show('over');
    }
  }

  /* ---------------- partida ---------------- */
  function startGame() {
    const user = getCurrentUser() || SAVE.playerName || '';
    if (!user) {
      openAuth();
      return;
    }
    AudioEngine.unlock();
    hide('menu'); hide('shop'); hide('help'); hide('pause'); hide('over');
    hide('storyScreen'); hide('rankingScreen'); hide('profileScreen'); hide('optionsScreen'); hide('adminPanel'); hide('authScreen'); hide('friendsScreen');
    setPlaying(true);
    alienCards();
    startQuickRun();
  }

  function startFree() {
    const user = getCurrentUser() || SAVE.playerName || '';
    if (!user) { openAuth(); return; }
    AudioEngine.unlock();
    hide('menu');
    setPlaying(true);
    alienCards();
    startFreeRun();
  }

  function pauseGame() {
    if (G.state !== 'playing') return;
    G.state = 'paused';
    show('pause');
    AudioEngine.sfx('click');
  }

  function resumeGame() {
    if (G.state !== 'paused') return;
    hide('pause');
    hide('shop');
    G.state = 'playing';
    AudioEngine.sfx('click');
  }

  function togglePause() {
    if (!D.shop.classList.contains('hidden')) return;
    if (G.state === 'playing') pauseGame();
    else if (G.state === 'paused') resumeGame();
  }

  function leaveGame() {
    hide('pause'); hide('over'); hide('shop'); hide('help');
    quitToMenu();
  }

  function gameOverScreen() {
    if (D.overWave) D.overWave.textContent = G.wave;
    if (D.overScore) D.overScore.textContent = G.score;
    if (D.overBest) D.overBest.textContent = SAVE.best | 0;
    if (D.runCoins) D.runCoins.textContent = G.runCoins;
    if (D.runGems) D.runGems.textContent = G.runGems;
    if (D.overMsg) {
      D.overMsg.textContent = G.wave >= 5
        ? 'Caíste en la oleada ' + G.wave + '. El Omnitrix resistió ' + G.kills + ' bajas enemigas.'
        : 'Los monstruos te superaron en la oleada ' + G.wave + '.';
    }
    setPlaying(false);
    hide('pause'); hide('shop');
    show('over');
    menuStats();
  }

  /* ---------------- controles ---------------- */
  function bindTouch() {
    const stick = D.stick, knob = D.knob;
    let stickId = null;

    function setStick(e) {
      const r = stick.getBoundingClientRect();
      const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      let dx = e.clientX - cx, dy = e.clientY - cy;
      const max = r.width * 0.34;
      const l = Math.hypot(dx, dy);
      if (l > max) { dx = dx / l * max; dy = dy / l * max; }
      input.joy.x = dx / max;
      input.joy.y = dy / max;
      knob.style.transform = 'translate(calc(-50% + ' + dx + 'px), calc(-50% + ' + dy + 'px))';
    }

    function resetStick() {
      stickId = null;
      input.joy.x = 0; input.joy.y = 0;
      knob.style.transform = 'translate(-50%,-50%)';
    }

    stick.addEventListener('pointerdown', e => {
      e.preventDefault();
      stickId = e.pointerId;
      stick.setPointerCapture(e.pointerId);
      setStick(e);
    });
    stick.addEventListener('pointermove', e => {
      if (e.pointerId === stickId) { e.preventDefault(); setStick(e); }
    });
    stick.addEventListener('pointerup', resetStick);
    stick.addEventListener('pointercancel', resetStick);

    function holdAttack(e) {
      e.preventDefault();
      input.attack = true;
    }
    function releaseAttack() { input.attack = false; }
    D.btnA.addEventListener('pointerdown', holdAttack);
    D.btnA.addEventListener('pointerup', releaseAttack);
    D.btnA.addEventListener('pointercancel', releaseAttack);
    D.btnA.addEventListener('pointerleave', releaseAttack);
    D.btnB.addEventListener('pointerdown', e => { e.preventDefault(); useSpecial(); });
    D.btnDash.addEventListener('pointerdown', e => { e.preventDefault(); dash(); });
  }

  function bindKeys() {
    const map = {
      'w': 'w', 'arrowup': 'w',
      's': 's', 'arrowdown': 's',
      'a': 'a', 'arrowleft': 'a',
      'd': 'd', 'arrowright': 'd'
    };
    window.addEventListener('keydown', e => {
      const k = (e.key || '').toLowerCase();
      if (k === ' ' || k.indexOf('arrow') === 0) e.preventDefault();
      if (map[k]) { keys[map[k]] = true; return; }
      if (e.repeat) return;
      checkGodKey(k);
      if (k === 'j' || k === ' ') input.attack = true;
      else if (k === 'k') useSpecial();
      else if (k === 'shift') dash();
      else if (k === 'e') { if (P && G.state === 'playing') revertToBen(false); }
      else if (k === 'p' || k === 'escape') togglePause();
      else if (k === 'm') toggleMute();
      else if (k >= '1' && k <= '7') {
        const a = ALIEN_ORDER[parseInt(k, 10) - 1];
        if (a) transformTo(a.id);
      }
    });
    window.addEventListener('keyup', e => {
      const k = (e.key || '').toLowerCase();
      if (map[k]) keys[map[k]] = false;
      if (k === 'j' || k === ' ') input.attack = false;
    });
    window.addEventListener('blur', () => {
      keys.w = keys.a = keys.s = keys.d = false;
      input.attack = false;
      input.joy.x = input.joy.y = 0;
    });
  }

  function bindUI() {
    // Menú principal
    if (D.btnStory) D.btnStory.addEventListener('click', () => { AudioEngine.sfx('click'); openStory(); });
    if (D.btnFree) D.btnFree.addEventListener('click', () => { AudioEngine.sfx('click'); startFree(); });
    if (D.btnRanking) D.btnRanking.addEventListener('click', () => { AudioEngine.sfx('click'); openRanking(); });
    if (D.btnOptions) D.btnOptions.addEventListener('click', () => { AudioEngine.sfx('click'); openOptions(); });
    if (D.startBtn) D.startBtn.addEventListener('click', startGame);

    // Perfil
    if (D.btnChangeName) D.btnChangeName.addEventListener('click', () => { hide('menu'); showAuthForm('login'); show('authScreen'); });
    if (D.btnLogout) D.btnLogout.addEventListener('click', doLogout);

    // Auth
    if (D.btnLogin) D.btnLogin.addEventListener('click', doLogin);
    if (D.btnRegister) D.btnRegister.addEventListener('click', doRegister);
    if (D.btnShowRegister) D.btnShowRegister.addEventListener('click', () => { showAuthForm('register'); });
    if (D.btnShowLogin) D.btnShowLogin.addEventListener('click', () => { showAuthForm('login'); });
    if (D.btnBackAuth) D.btnBackAuth.addEventListener('click', () => { hide('authScreen'); show('menu'); });
    if (D.loginUsername) D.loginUsername.addEventListener('keydown', e => { if (e.key === 'Enter') doLogin(); });
    if (D.loginPassword) D.loginPassword.addEventListener('keydown', e => { if (e.key === 'Enter') doLogin(); });
    if (D.registerUsername) D.registerUsername.addEventListener('keydown', e => { if (e.key === 'Enter') doRegister(); });
    if (D.registerPassword) D.registerPassword.addEventListener('keydown', e => { if (e.key === 'Enter') doRegister(); });
    if (D.registerConfirm) D.registerConfirm.addEventListener('keydown', e => { if (e.key === 'Enter') doRegister(); });

    // Historia
    if (D.btnBackStory) D.btnBackStory.addEventListener('click', () => { hide('storyScreen'); show('menu'); });

    // Ranking
    if (D.btnBackRanking) D.btnBackRanking.addEventListener('click', () => { hide('rankingScreen'); show('menu'); });
    if (D.btnRefreshRanking) D.btnRefreshRanking.addEventListener('click', () => { AudioEngine.sfx('click'); loadRanking(); });

    // Opciones
    if (D.btnBackOptions) D.btnBackOptions.addEventListener('click', () => { hide('optionsScreen'); show('menu'); });
    if (D.optMuteBtn) D.optMuteBtn.addEventListener('click', toggleMute);
    if (D.optQualityBtn) D.optQualityBtn.addEventListener('click', () => {
      AudioEngine.sfx('click');
      toast('Calidad gráfica ajustada');
    });
    if (D.optGodBtn) D.optGodBtn.addEventListener('click', () => { AudioEngine.sfx('click'); toggleGodMode(); });
    if (D.btnAddMod) D.btnAddMod.addEventListener('click', addMod);

    // Admin
    if (D.btnBackAdmin) D.btnBackAdmin.addEventListener('click', () => { hide('adminPanel'); show('optionsScreen'); });

    // Controles táctiles
    if (D.btnControls) D.btnControls.addEventListener('click', () => { AudioEngine.sfx('click'); openControls(); });
    if (D.btnBackControls) D.btnBackControls.addEventListener('click', () => { hide('controlsScreen'); show('menu'); });
    if (D.btnSaveControls) D.btnSaveControls.addEventListener('click', () => { AudioEngine.sfx('click'); applyControlsConfig(); });
    if (D.btnResetControls) D.btnResetControls.addEventListener('click', () => { AudioEngine.sfx('click'); resetControls(); });
    if (D.ctrlStickSize) D.ctrlStickSize.addEventListener('input', (e) => {
      const v = e.target.value; CTRLS.stick.w = Math.round(v); CTRLS.stick.h = Math.round(v);
      initControlsPreview();
    });
    if (D.ctrlBtnSize) D.ctrlBtnSize.addEventListener('input', (e) => {
      const v = e.target.value; CTRLS.btnA.w = Math.round(v); CTRLS.btnA.h = Math.round(v);
      CTRLS.btnB.w = Math.round(v); CTRLS.btnB.h = Math.round(v);
      CTRLS.btnDash.w = Math.round(v * 0.82); CTRLS.btnDash.h = Math.round(v * 0.82);
      initControlsPreview();
    });
    if (D.ctrlScale) D.ctrlScale.addEventListener('input', (e) => {
      CTRLS.scale = Math.round(e.target.value);
      initControlsPreview();
    });
    if (D.ctrlLayoutLeft) D.ctrlLayoutLeft.addEventListener('click', () => { CTRLS.layout = 'left'; initControlsPreview(); });
    if (D.ctrlLayoutRight) D.ctrlLayoutRight.addEventListener('click', () => { CTRLS.layout = 'right'; initControlsPreview(); });

    // Amigos
    if (D.btnFriends) D.btnFriends.addEventListener('click', () => { AudioEngine.sfx('click'); openFriends(); });
    if (D.btnBackFriends) D.btnBackFriends.addEventListener('click', () => { hide('friendsScreen'); show('menu'); });
    if (D.btnAddFriend) D.btnAddFriend.addEventListener('click', doAddFriend);
    if (D.friendNameInput) D.friendNameInput.addEventListener('keydown', e => { if (e.key === 'Enter') doAddFriend(); });

    // Tienda
    if (D.shopBtn) D.shopBtn.addEventListener('click', () => openShop('menu'));
    if (D.helpBtn) D.helpBtn.addEventListener('click', () => { show('help'); AudioEngine.sfx('click'); });
    if (D.helpClose) D.helpClose.addEventListener('click', () => hide('help'));
    if (D.shopClose) D.shopClose.addEventListener('click', closeShop);
    if (D.menuMuteBtn) D.menuMuteBtn.addEventListener('click', toggleMute);
    if (D.muteBtn) D.muteBtn.addEventListener('click', toggleMute);
    if (D.pauseBtn) D.pauseBtn.addEventListener('click', pauseGame);
    if (D.resumeBtn) D.resumeBtn.addEventListener('click', resumeGame);
    if (D.pauseShopBtn) D.pauseShopBtn.addEventListener('click', () => openShop('pause'));
    if (D.quitBtn) D.quitBtn.addEventListener('click', leaveGame);
    if (D.retryBtn) D.retryBtn.addEventListener('click', startGame);
    if (D.overShopBtn) D.overShopBtn.addEventListener('click', () => openShop('over'));
    if (D.menuBtn) D.menuBtn.addEventListener('click', leaveGame);

    document.querySelectorAll('.tab').forEach(t => {
      t.addEventListener('click', () => {
        shopTab = t.dataset.tab;
        AudioEngine.sfx('click');
        renderShop();
      });
    });

    D.shopGrid.addEventListener('click', e => {
      const b = e.target.closest('[data-buy]');
      if (!b) return;
      const parts = b.dataset.buy.split(':');
      handleBuy(parts[0], parts[1]);
    });

    document.addEventListener('pointerdown', () => AudioEngine.unlock(), { passive: true });
    document.addEventListener('click', e => {
      if (e.target.closest('button')) AudioEngine.sfx('click');
    });
    document.addEventListener('mouseover', e => {
      if (!e.target.closest('button')) return;
      const now = performance.now();
      if (now - hoverAt < 60) return;
      hoverAt = now;
      AudioEngine.sfx('hover');
    });
    document.addEventListener('contextmenu', e => e.preventDefault());
  }

  let last = 0;
  function loop(now) {
    requestAnimationFrame(loop);
    if (!last) last = now;
    let dt = (now - last) / 1000;
    last = now;
    if (dt > 0.05) dt = 0.05;
    if (dt < 0) dt = 0;

    if (G.state === 'playing') update(dt);
    Engine.updateFX(dt);
    Engine.updateFlash(dt);

    const mode = (G.state === 'playing' || G.state === 'paused' || G.state === 'over') && P ? 'play' : 'menu';
    Engine.updateCamera(dt, mode, P ? P.pos : null, G.moving);
    Engine.render();

    hudT -= dt;
    if (hudT <= 0) {
      hudT = 0.1;
      if (G.state === 'playing') {
        refresh();
        updateStoryHUD();
      }
    }
  }

  function boot() {
    cache();
    try {
      Engine.init(D.game);
    } catch (e) {
      console.error(e);
      if (D.boot) {
        D.boot.innerHTML = '<div class="omnitrixSpinner" style="animation:none;border-top-color:#ff6b7a"></div>' +
          '<strong>WEBGL NO DISPONIBLE</strong>' +
          '<span>Actualizá el navegador o activá la aceleración por hardware.</span>';
      }
      return;
    }

    const isTouch = window.matchMedia('(pointer: coarse)').matches || navigator.maxTouchPoints > 0;
    if (isTouch) document.body.classList.add('touch');
    document.body.classList.toggle('gold', SAVE.skin === 'gold');

    buildBaseUI();
    bindUI();
    bindKeys();
    bindTouch();
    updateMute();
    wallet();
    menuStats();
    alienCards();
    AudioEngine.setMuted(SAVE.muted);

    G.state = 'menu';
    loadProfile();
    updateMenuAdmin();
    requestAnimationFrame(loop);

    setTimeout(() => {
      if (D.boot) {
        D.boot.classList.add('hidden');
        setTimeout(() => { if (D.boot && D.boot.parentNode) D.boot.parentNode.removeChild(D.boot); }, 450);
      }
    }, 650);
  }

  function buildBaseUI() {}

  /* ==================== Tienda de Personajes ==================== */
  function renderCharStore() {
    if (!D.charStore) return;
    let html = '';
    CHARACTERS.forEach(c => {
      const owned = isCharacterOwned(c.id);
      const f = FORMS[c.id] || {};
      html += '<div class="charCard ' + (owned ? 'owned' : 'locked') + '">' +
        '<span class="ico">' + c.icon + '</span>' +
        '<h4>' + c.name + '</h4>' +
        '<p>' + (f.desc || 'Personaje especial') + '</p>' +
        (owned
          ? '<div class="price">✅ DESBLOQUEADO</div>'
          : '<div class="price">' + (c.cur === 'gems' ? '💎' : '🪙') + ' ' + c.price.toLocaleString('es-AR') + '</div>' +
            '<button class="priceBtn ' + (c.cur === 'gems' ? 'gem' : '') + '" data-buy="char:' + c.id + '">' +
            (c.cur === 'gems' ? 'COMPRAR CON DIAMANTES' : 'COMPRAR CON MONEDAS') + '</button>') +
        '</div>';
    });
    D.charStore.innerHTML = html;

    D.charStore.querySelectorAll('[data-buy]').forEach(b => {
      b.addEventListener('click', () => {
        const id = b.dataset.buy.split(':')[1];
        const res = unlockCharacter(id);
        toast(res.msg);
        if (res.ok) {
          renderCharStore();
          alienCards();
          wallet();
          refresh();
        }
      });
    });
  }

  function openCharStore() {
    hide('menu');
    renderCharStore();
    show('charStoreScreen');
  }

  /* ==================== Diálogo NPC ==================== */
  let npcCurrentId = null;
  let npcCurrentIndex = 0;

  function openNPCDialog(npcId) {
    npcCurrentId = npcId;
    npcCurrentIndex = 0;
    const d = getNPCDialog(npcId, 0);
    if (!d) return;
    if (D.npcName) D.npcName.textContent = d.name;
    if (D.npcText) D.npcText.textContent = d.text;
    if (D.npcDialog) D.npcDialog.classList.remove('hidden');
  }

  function nextNPCDialog() {
    if (!npcCurrentId) return;
    npcCurrentIndex++;
    const d = getNPCDialog(npcCurrentId, npcCurrentIndex);
    if (!d) {
      if (D.npcDialog) D.npcDialog.classList.add('hidden');
      npcCurrentId = null;
      npcCurrentIndex = 0;
      return;
    }
    if (D.npcName) D.npcName.textContent = d.name;
    if (D.npcText) D.npcText.textContent = d.text;
  }

  function closeNPCDialog() {
    if (D.npcDialog) D.npcDialog.classList.add('hidden');
    npcCurrentId = null;
    npcCurrentIndex = 0;
  }

  /* ==================== Personalizar Controles Táctiles ==================== */
  const CTRL_KEY = 'ben10_touch_controls';
  const DEFAULT_CTRLS = {
    stick: { x: 40, y: 40, w: 118, h: 118 },
    btnA:  { x: 0, y: 0, w: 68, h: 68 },
    btnB:  { x: 0, y: 0, w: 68, h: 68 },
    btnDash: { x: 0, y: 0, w: 56, h: 56 },
    scale: 100,
    layout: 'left'
  };

  function loadControlsConfig() {
    try {
      const raw = localStorage.getItem(CTRL_KEY);
      if (!raw) return JSON.parse(JSON.stringify(DEFAULT_CTRLS));
      return Object.assign({}, DEFAULT_CTRLS, JSON.parse(raw));
    } catch (e) {
      return JSON.parse(JSON.stringify(DEFAULT_CTRLS));
    }
  }

  function saveControlsConfig(cfg) {
    try { localStorage.setItem(CTRL_KEY, JSON.stringify(cfg)); } catch (e) {}
  }

  let CTRLS = loadControlsConfig();
  let ctrlDragging = null;
  let ctrlOffset = { x: 0, y: 0 };
  let ctrlPreviewEls = {};

  function initControlsPreview() {
    if (!D.controlsPreview) return;
    D.controlsPreview.innerHTML = '';

    const scale = CTRLS.scale / 100;

    // Clonar joystick
    const stick = document.createElement('div');
    stick.id = 'ctrlEditStick';
    stick.className = 'controlEditable';
    stick.style.left = (CTRLS.stick.x * scale) + 'px';
    stick.style.top = (CTRLS.stick.y * scale) + 'px';
    stick.style.width = (CTRLS.stick.w * scale) + 'px';
    stick.style.height = (CTRLS.stick.h * scale) + 'px';
    stick.style.background = 'radial-gradient(circle, rgba(30,90,60,.4), rgba(10,30,20,.3))';
    stick.style.border = '2px solid rgba(110,255,180,.4)';
    stick.style.borderRadius = '50%';
    stick.innerHTML = '<div class="ctrlHandle">↕</div><div class="ctrlLabel">Joystick</div>';
    D.controlsPreview.appendChild(stick);
    ctrlPreviewEls.stick = stick;

    // Botón A (Golpe)
    const btnA = document.createElement('div');
    btnA.id = 'ctrlEditBtnA';
    btnA.className = 'controlEditable';
    btnA.style.left = (CTRLS.btnA.x * scale) + 'px';
    btnA.style.top = (CTRLS.btnA.y * scale) + 'px';
    btnA.style.width = (CTRLS.btnA.w * scale) + 'px';
    btnA.style.height = (CTRLS.btnA.h * scale) + 'px';
    btnA.style.background = 'radial-gradient(circle at 35% 30%, rgba(70,180,120,.5), rgba(10,45,28,.6))';
    btnA.style.border = '2px solid rgba(150,255,200,.4)';
    btnA.style.borderRadius = '50%';
    btnA.innerHTML = '<div class="ctrlHandle">↕</div><div class="ctrlLabel">GOLPE</div>';
    D.controlsPreview.appendChild(btnA);
    ctrlPreviewEls.btnA = btnA;

    // Botón B (Poder)
    const btnB = document.createElement('div');
    btnB.id = 'ctrlEditBtnB';
    btnB.className = 'controlEditable';
    btnB.style.left = (CTRLS.btnB.x * scale) + 'px';
    btnB.style.top = (CTRLS.btnB.y * scale) + 'px';
    btnB.style.width = (CTRLS.btnB.w * scale) + 'px';
    btnB.style.height = (CTRLS.btnB.h * scale) + 'px';
    btnB.style.background = 'radial-gradient(circle at 35% 30%, rgba(255,170,70,.5), rgba(60,25,8,.6))';
    btnB.style.border = '2px solid rgba(255,200,130,.45)';
    btnB.style.borderRadius = '50%';
    btnB.innerHTML = '<div class="ctrlHandle">↕</div><div class="ctrlLabel">PODER</div>';
    D.controlsPreview.appendChild(btnB);
    ctrlPreviewEls.btnB = btnB;

    // Botón Dash
    const btnDash = document.createElement('div');
    btnDash.id = 'ctrlEditBtnDash';
    btnDash.className = 'controlEditable';
    btnDash.style.left = (CTRLS.btnDash.x * scale) + 'px';
    btnDash.style.top = (CTRLS.btnDash.y * scale) + 'px';
    btnDash.style.width = (CTRLS.btnDash.w * scale) + 'px';
    btnDash.style.height = (CTRLS.btnDash.h * scale) + 'px';
    btnDash.style.background = 'radial-gradient(circle at 35% 30%, rgba(90,160,255,.5), rgba(10,25,60,.6))';
    btnDash.style.border = '2px solid rgba(140,200,255,.4)';
    btnDash.style.borderRadius = '50%';
    btnDash.innerHTML = '<div class="ctrlHandle">↕</div><div class="ctrlLabel">ESQUIVA</div>';
    D.controlsPreview.appendChild(btnDash);
    ctrlPreviewEls.btnDash = btnDash;

    bindControlEditors();
    updateControlSliders();
  }

  function bindControlEditors() {
    Object.keys(ctrlPreviewEls).forEach(key => {
      const el = ctrlPreviewEls[key];
      const handle = el.querySelector('.ctrlHandle');

      // Arrastrar
      el.addEventListener('mousedown', startDrag);
      el.addEventListener('touchstart', startDrag, { passive: false });

      // Redimensionar con el handle
      handle.addEventListener('mousedown', (e) => { e.stopPropagation(); startResize(e, key); });
      handle.addEventListener('touchstart', (e) => { e.stopPropagation(); e.preventDefault(); startResize(e, key); }, { passive: false });
    });
  }

  function startDrag(e) {
    const el = e.currentTarget;
    ctrlDragging = el;
    const rect = el.getBoundingClientRect();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    ctrlOffset.x = clientX - rect.left;
    ctrlOffset.y = clientY - rect.top;
    el.classList.add('dragging');

    const move = (ev) => {
      if (!ctrlDragging) return;
      const cx = ev.touches ? ev.touches[0].clientX : ev.clientX;
      const cy = ev.touches ? ev.touches[0].clientY : ev.clientY;
      const preview = D.controlsPreview;
      const pr = preview.getBoundingClientRect();
      const scale = CTRLS.scale / 100;
      let nx = cx - pr.left - ctrlOffset.x;
      let ny = cy - pr.top - ctrlOffset.y;
      nx = Math.max(0, Math.min(nx, pr.width - el.offsetWidth));
      ny = Math.max(0, Math.min(ny, pr.height - el.offsetHeight));
      el.style.left = nx + 'px';
      el.style.top = ny + 'px';
      saveControlPos(el.id.replace('ctrlEdit', ''), nx / scale, ny / scale);
    };

    const end = () => {
      if (ctrlDragging) ctrlDragging.classList.remove('dragging');
      ctrlDragging = null;
      window.removeEventListener('mousemove', move);
      window.removeEventListener('touchmove', move);
      window.removeEventListener('mouseup', end);
      window.removeEventListener('touchend', end);
    };

    window.addEventListener('mousemove', move);
    window.addEventListener('touchmove', move, { passive: false });
    window.addEventListener('mouseup', end);
    window.addEventListener('touchend', end);
  }

  function startResize(e, key) {
    const el = ctrlPreviewEls[key];
    const startX = e.touches ? e.touches[0].clientX : e.clientX;
    const startY = e.touches ? e.touches[0].clientY : e.clientY;
    const startW = el.offsetWidth;
    const startH = el.offsetHeight;
    const scale = CTRLS.scale / 100;

    const move = (ev) => {
      const cx = ev.touches ? ev.touches[0].clientX : ev.clientX;
      const cy = ev.touches ? ev.touches[0].clientY : ev.clientY;
      let nw = startW + (cx - startX) / scale;
      let nh = startH + (cy - startY) / scale;
      nw = Math.max(40, Math.min(nw, 240));
      nh = Math.max(40, Math.min(nh, 240));
      el.style.width = nw + 'px';
      el.style.height = nh + 'px';
      saveControlSize(key, nw / scale, nh / scale);
    };

    const end = () => {
      window.removeEventListener('mousemove', move);
      window.removeEventListener('touchmove', move);
      window.removeEventListener('mouseup', end);
      window.removeEventListener('touchend', end);
    };

    window.addEventListener('mousemove', move);
    window.addEventListener('touchmove', move, { passive: false });
    window.addEventListener('mouseup', end);
    window.addEventListener('touchend', end);
  }

  function saveControlPos(key, x, y) {
    if (key === 'Stick') CTRLS.stick.x = Math.round(x);
    else if (key === 'BtnA') CTRLS.btnA.x = Math.round(x);
    else if (key === 'BtnB') CTRLS.btnB.x = Math.round(x);
    else if (key === 'BtnDash') CTRLS.btnDash.x = Math.round(x);
    if (key === 'Stick') CTRLS.stick.y = Math.round(y);
    else if (key === 'BtnA') CTRLS.btnA.y = Math.round(y);
    else if (key === 'BtnB') CTRLS.btnB.y = Math.round(y);
    else if (key === 'BtnDash') CTRLS.btnDash.y = Math.round(y);
  }

  function saveControlSize(key, w, h) {
    if (key === 'stick') { CTRLS.stick.w = Math.round(w); CTRLS.stick.h = Math.round(h); }
    else if (key === 'btnA') { CTRLS.btnA.w = Math.round(w); CTRLS.btnA.h = Math.round(h); }
    else if (key === 'btnB') { CTRLS.btnB.w = Math.round(w); CTRLS.btnB.h = Math.round(h); }
    else if (key === 'btnDash') { CTRLS.btnDash.w = Math.round(w); CTRLS.btnDash.h = Math.round(h); }
  }

  function updateControlSliders() {
    if (D.ctrlStickSize) D.ctrlStickSize.value = CTRLS.stick.w;
    if (D.ctrlBtnSize) D.ctrlBtnSize.value = CTRLS.btnA.w;
    if (D.ctrlScale) D.ctrlScale.value = CTRLS.scale;
  }

  function applyControlsConfig() {
    if (!D.touch) return;
    const scale = CTRLS.scale / 100;

    // Aplicar al joystick real
    if (D.stick) {
      D.stick.style.left = (CTRLS.stick.x * scale) + 'px';
      D.stick.style.bottom = 'auto';
      D.stick.style.top = (CTRLS.stick.y * scale) + 'px';
      D.stick.style.width = (CTRLS.stick.w * scale) + 'px';
      D.stick.style.height = (CTRLS.stick.h * scale) + 'px';
      if (D.knob) {
        D.knob.style.width = (Math.round(52 * scale)) + 'px';
        D.knob.style.height = (Math.round(52 * scale)) + 'px';
      }
    }

    // Aplicar a botones de acción
    if (D.btnA) {
      D.btnA.style.width = (CTRLS.btnA.w * scale) + 'px';
      D.btnA.style.height = (CTRLS.btnA.h * scale) + 'px';
      // reposicionar relativo a la esquina inferior derecha
      D.btnA.style.right = (20 + CTRLS.btnA.x * scale) + 'px';
      D.btnA.style.bottom = 'auto';
      D.btnA.style.top = (CTRLS.btnA.y * scale) + 'px';
    }
    if (D.btnB) {
      D.btnB.style.width = (CTRLS.btnB.w * scale) + 'px';
      D.btnB.style.height = (CTRLS.btnB.h * scale) + 'px';
      D.btnB.style.right = (110 + CTRLS.btnB.x * scale) + 'px';
      D.btnB.style.bottom = 'auto';
      D.btnB.style.top = (CTRLS.btnB.y * scale) + 'px';
    }
    if (D.btnDash) {
      D.btnDash.style.width = (CTRLS.btnDash.w * scale) + 'px';
      D.btnDash.style.height = (CTRLS.btnDash.h * scale) + 'px';
      D.btnDash.style.right = (20 + CTRLS.btnDash.x * scale) + 'px';
      D.btnDash.style.bottom = 'auto';
      D.btnDash.style.top = (80 + CTRLS.btnDash.y * scale) + 'px';
    }

    saveControlsConfig(CTRLS);
    toast('✅ Controles guardados');
  }

  function resetControls() {
    CTRLS = JSON.parse(JSON.stringify(DEFAULT_CTRLS));
    initControlsPreview();
    applyControlsConfig();
    toast('↻ Controles restablecidos');
  }

  function openControls() {
    hide('menu');
    initControlsPreview();
    show('controlsScreen');
  }

  /* ==================== Menú principal: agregar botones ==================== */

  return {
    boot, show, hide, toast, banner, refresh, wallet, menuStats, alienCards,
    combo, boss, setPlaying, gameOver: gameOverScreen, hurtFlash,
    updateMute, openShop, closeShop, startGame, togglePause, hurtFlash, screenFlash,
    openAuth, loadProfile, openStory, openRanking, openOptions, openAdmin, openFriends,
    updateStoryHUD, showGodIndicator, renderFriendsList, loadModerators, renderAdminList,
    doLogin, doRegister, doLogout, doAddFriend, openControls, applyControlsConfig,
    resetControls, CTRLS, loadControlsConfig, saveControlsConfig
  };
})();

UI.boot();
