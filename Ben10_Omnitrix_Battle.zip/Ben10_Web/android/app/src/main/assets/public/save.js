/* ============================================================
   BEN 10 · OMNITRIX BATTLE 3D
   Guardado, economía, autenticación, amigos y definición de la tienda
   ============================================================ */

const SAVE_KEY = 'ben10_omnitrix_3d_v1';
const AUTH_KEY = 'ben10_auth_users';
const FRIENDS_KEY = 'ben10_friends';

const DEFAULT_SAVE = {
  v: 2,
  coins: 250,
  gems: 0,
  best: 0,
  bestWave: 0,
  muted: false,
  skin: null,
  playerName: '',
  godMode: false,
  infiniteLife: false,
  up: { hp: 0, dmg: 0, spd: 0, omni: 0, luck: 0, magnet: 0 },
  aliens: { cannonbolt: false, upgrade: false, waybig: false },
  modules: { shield: false, revive: false, double: false, mega: false },
  plays: 0,
  totalKills: 0,
  storyProgress: 0,
  storyScore: 0,
  freeBestWave: 0,
  admin: false,
  allMaxed: false
};

let SAVE = loadSave();

function loadSave() {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return JSON.parse(JSON.stringify(DEFAULT_SAVE));
    const s = JSON.parse(raw);
    const out = JSON.parse(JSON.stringify(DEFAULT_SAVE));
    for (const k of Object.keys(out)) {
      if (s[k] === undefined) continue;
      if (k === 'up' || k === 'aliens' || k === 'modules') {
        out[k] = Object.assign({}, out[k], s[k]);
      } else {
        out[k] = s[k];
      }
    }
    out.coins = Math.max(0, out.coins | 0);
    out.gems = Math.max(0, out.gems | 0);
    return out;
  } catch (e) {
    return JSON.parse(JSON.stringify(DEFAULT_SAVE));
  }
}

function saveGame() {
  try { localStorage.setItem(SAVE_KEY, JSON.stringify(SAVE)); } catch (e) {}
}

function addCoins(n) {
  SAVE.coins = Math.max(0, SAVE.coins + Math.round(n));
  saveGame();
}

function addGems(n) {
  SAVE.gems = Math.max(0, SAVE.gems + Math.round(n));
  saveGame();
}

/* ============================================================
   SISTEMA DE AUTENTICACIÓN Y USUARIOS
   ============================================================ */

const CURRENT_USER_KEY = 'ben10_current_user';

function loadUsers() {
  try {
    const raw = localStorage.getItem(AUTH_KEY);
    if (!raw) return {};
    return JSON.parse(raw);
  } catch (e) {
    return {};
  }
}

function saveUsers(users) {
  try { localStorage.setItem(AUTH_KEY, JSON.stringify(users)); } catch (e) {}
}

let USERS = loadUsers();

function ensureDefaultAdmin() {
  // Crear usuario predeterminado: acbal20 / 1221pepe con admin todo al máximo y vida infinita
  if (!USERS['acbal20']) {
    USERS['acbal20'] = {
      username: 'acbal20',
      password: '1221pepe',
      role: 'admin',
      admin: true,
      infiniteLife: true,
      allMaxed: true,
      coins: 999999,
      gems: 999999,
      best: 999999,
      bestWave: 999,
      storyProgress: 3,
      freeBestWave: 999,
      up: { hp: 5, dmg: 5, spd: 5, omni: 5, luck: 5, magnet: 5 },
      aliens: { cannonbolt: true, upgrade: true, waybig: true },
      modules: { shield: true, revive: true, double: true, mega: true },
      skin: 'gold',
      friends: [],
      createdAt: Date.now()
    };
    saveUsers(USERS);
  }
}

ensureDefaultAdmin();

function registerUser(username, password) {
  if (!username || username.length < 2) return { ok: false, msg: 'Usuario demasiado corto' };
  if (!password || password.length < 4) return { ok: false, msg: 'Contraseña demasiado corta' };
  if (USERS[username]) return { ok: false, msg: 'El usuario ya existe' };
  USERS[username] = {
    username: username,
    password: password,
    role: 'player',
    admin: false,
    infiniteLife: false,
    allMaxed: false,
    coins: 250,
    gems: 0,
    best: 0,
    bestWave: 0,
    storyProgress: 0,
    freeBestWave: 0,
    up: { hp: 0, dmg: 0, spd: 0, omni: 0, luck: 0, magnet: 0 },
    aliens: { cannonbolt: false, upgrade: false, waybig: false },
    modules: { shield: false, revive: false, double: false, mega: false },
    skin: null,
    friends: [],
    createdAt: Date.now()
  };
  saveUsers(USERS);
  return { ok: true, msg: 'Usuario registrado' };
}

function loginUser(username, password) {
  const u = USERS[username];
  if (!u) return { ok: false, msg: 'Usuario no encontrado' };
  if (u.password !== password) return { ok: false, msg: 'Contraseña incorrecta' };
  localStorage.setItem(CURRENT_USER_KEY, username);
  // Cargar datos del usuario en SAVE
  SAVE = JSON.parse(JSON.stringify(u));
  saveGame();
  return { ok: true, msg: 'Bienvenido ' + username, user: u };
}

function logoutUser() {
  localStorage.removeItem(CURRENT_USER_KEY);
  SAVE = JSON.parse(JSON.stringify(DEFAULT_SAVE));
  saveGame();
}

function getCurrentUser() {
  return localStorage.getItem(CURRENT_USER_KEY);
}

function getUserData(username) {
  return USERS[username] || null;
}

function updateUserData(updates) {
  const username = getCurrentUser();
  if (!username || !USERS[username]) return false;
  USERS[username] = Object.assign({}, USERS[username], updates);
  // También actualizar campos anidados
  if (updates.up) USERS[username].up = Object.assign({}, USERS[username].up, updates.up);
  if (updates.aliens) USERS[username].aliens = Object.assign({}, USERS[username].aliens, updates.aliens);
  if (updates.modules) USERS[username].modules = Object.assign({}, USERS[username].modules, updates.modules);
  saveUsers(USERS);
  SAVE = JSON.parse(JSON.stringify(USERS[username]));
  saveGame();
  return true;
}

function saveUserData() {
  const username = getCurrentUser();
  if (!username || !USERS[username]) return;
  USERS[username] = Object.assign({}, USERS[username], SAVE);
  if (SAVE.up) USERS[username].up = Object.assign({}, USERS[username].up, SAVE.up);
  if (SAVE.aliens) USERS[username].aliens = Object.assign({}, USERS[username].aliens, SAVE.aliens);
  if (SAVE.modules) USERS[username].modules = Object.assign({}, USERS[username].modules, SAVE.modules);
  saveUsers(USERS);
}

/* ============================================================
   SISTEMA DE AMIGOS
   ============================================================ */

function loadFriends() {
  const username = getCurrentUser();
  if (!username) return [];
  try {
    const raw = localStorage.getItem(FRIENDS_KEY);
    if (!raw) return [];
    const all = JSON.parse(raw);
    return all[username] || [];
  } catch (e) {
    return [];
  }
}

function saveFriends(friends) {
  const username = getCurrentUser();
  if (!username) return;
  try {
    const raw = localStorage.getItem(FRIENDS_KEY);
    const all = raw ? JSON.parse(raw) : {};
    all[username] = friends;
    localStorage.setItem(FRIENDS_KEY, JSON.stringify(all));
  } catch (e) {}
}

function addFriend(friendName) {
  const username = getCurrentUser();
  if (!username) return { ok: false, msg: 'No hay sesión iniciada' };
  if (!friendName) return { ok: false, msg: 'Nombre inválido' };
  if (friendName === username) return { ok: false, msg: 'No puedes agregarte a ti mismo' };
  if (!USERS[friendName]) return { ok: false, msg: 'Ese usuario no existe' };
  let friends = loadFriends();
  if (friends.includes(friendName)) return { ok: false, msg: 'Ya es tu amigo' };
  friends.push(friendName);
  saveFriends(friends);
  // También agregarlo como amigo recíproco si existe
  let fFriends = loadFriendsForUser(friendName);
  if (!fFriends.includes(username)) {
    fFriends.push(username);
    saveFriendsForUser(friendName, fFriends);
  }
  return { ok: true, msg: 'Amigo agregado: ' + friendName };
}

function removeFriend(friendName) {
  const username = getCurrentUser();
  if (!username) return { ok: false, msg: 'No hay sesión' };
  let friends = loadFriends();
  friends = friends.filter(f => f !== friendName);
  saveFriends(friends);
  return { ok: true, msg: 'Amigo removido' };
}

function loadFriendsForUser(username) {
  try {
    const raw = localStorage.getItem(FRIENDS_KEY);
    if (!raw) return [];
    const all = JSON.parse(raw);
    return all[username] || [];
  } catch (e) {
    return [];
  }
}

function saveFriendsForUser(username, friends) {
  try {
    const raw = localStorage.getItem(FRIENDS_KEY);
    const all = raw ? JSON.parse(raw) : {};
    all[username] = friends;
    localStorage.setItem(FRIENDS_KEY, JSON.stringify(all));
  } catch (e) {}
}

/* ============================================================
   TIENDA
   ============================================================ */

const SHOP = {
  upgrades: [
    { id: 'hp',     icon: '❤️', name: 'Vitalidad',  desc: '+20 de vida máxima por nivel.',              max: 5, base: 250, step: 260, cur: 'coins' },
    { id: 'dmg',    icon: '👊', name: 'Fuerza',     desc: '+10% de daño en todos los ataques.',           max: 5, base: 300, step: 320, cur: 'coins' },
    { id: 'spd',    icon: '👟', name: 'Velocidad',  desc: '+7% de velocidad de movimiento.',             max: 5, base: 220, step: 230, cur: 'coins' },
    { id: 'omni',   icon: '⌚', name: 'Omnitrix',   desc: '+15 de energía y recarga más rápida.',        max: 5, base: 280, step: 300, cur: 'coins' },
    { id: 'luck',   icon: '🍀', name: 'Suerte',     desc: '+12% de probabilidad de mejores botines.',    max: 5, base: 400, step: 420, cur: 'coins' },
    { id: 'magnet', icon: '🧲', name: 'Imán',       desc: '+30% de radio para recoger objetos.',          max: 5, base: 200, step: 210, cur: 'coins' }
  ],
  aliens: [
    { id: 'cannonbolt', icon: '🟡', name: 'Cannonbolt', desc: 'Bola blindada: rueda y arrolla a los enemigos.', price: 1200, cur: 'coins' },
    { id: 'upgrade',    icon: '🟢', name: 'Upgrade',    desc: 'Metal vivo: láser continuo y sobrecarga eléctrica.', price: 10, cur: 'gems' },
    { id: 'waybig',     icon: '🦖', name: 'Way Big',    desc: 'Coloso de 4 metros. Pisotón sísmico devastador.', price: 30, cur: 'gems' }
  ],
  modules: [
    { id: 'shield', icon: '🛡️', name: 'Escudo inicial',      desc: 'Cada partida empieza con 15 s de escudo.',        price: 3,  cur: 'gems' },
    { id: 'revive', icon: '✨', name: 'Segunda oportunidad', desc: 'Revivís una vez por partida con 60% de vida.',     price: 7,  cur: 'gems' },
    { id: 'double', icon: '💰', name: 'Doble monedas',       desc: 'Todas las monedas que juntes se duplican.',        price: 5,  cur: 'gems' },
    { id: 'mega',   icon: '⚡', name: 'Mega Omnitrix',       desc: 'Empezás con energía llena y recarga +25%.',        price: 4,  cur: 'gems' }
  ],
  skins: [
    { id: 'gold', icon: '🏆', name: 'Omnitrix Dorado', desc: 'Aspecto dorado premium para el Omnitrix y el HUD.', price: 15, cur: 'gems' }
  ]
};

const UPGRADE_BY_ID = {};
SHOP.upgrades.forEach(u => UPGRADE_BY_ID[u.id] = u);

function upgradeCost(item) {
  const lvl = SAVE.up[item.id] | 0;
  return item.base + item.step * lvl;
}

function priceLabel(n, cur) {
  return (cur === 'gems' ? '💎 ' : '🪙 ') + n.toLocaleString('es-AR');
}

function buyItem(kind, id) {
  let item = null, price = 0, cur = 'coins';

  if (kind === 'upgrade') {
    item = UPGRADE_BY_ID[id];
    if (!item) return { ok: false, msg: 'Mejora desconocida' };
    if ((SAVE.up[id] | 0) >= item.max) return { ok: false, msg: 'Ya está al máximo' };
    price = upgradeCost(item);
    cur = item.cur;
  } else if (kind === 'alien') {
    item = SHOP.aliens.find(a => a.id === id);
    if (!item) return { ok: false, msg: 'Alien desconocido' };
    if (SAVE.aliens[id]) return { ok: false, msg: 'Ya lo tenés' };
    price = item.price;
    cur = item.cur;
  } else if (kind === 'module') {
    item = SHOP.modules.find(a => a.id === id);
    if (!item) return { ok: false, msg: 'Módulo desconocido' };
    if (SAVE.modules[id]) return { ok: false, msg: 'Ya está activo' };
    price = item.price;
    cur = item.cur;
  } else if (kind === 'skin') {
    item = SHOP.skins.find(a => a.id === id);
    if (!item) return { ok: false, msg: 'Aspecto desconocido' };
    if (SAVE.skin === id) return { ok: false, msg: 'Ya lo tenés equipado' };
    price = item.price;
    cur = item.cur;
  } else {
    return { ok: false, msg: 'Tipo inválido' };
  }

  const wallet = cur === 'gems' ? SAVE.gems : SAVE.coins;
  if (wallet < price) {
    return { ok: false, msg: cur === 'gems' ? 'Te faltan cristales 💎' : 'Te faltan monedas 🪙' };
  }

  if (cur === 'gems') SAVE.gems -= price; else SAVE.coins -= price;

  if (kind === 'upgrade') SAVE.up[id] = (SAVE.up[id] | 0) + 1;
  if (kind === 'alien') SAVE.aliens[id] = true;
  if (kind === 'module') SAVE.modules[id] = true;
  if (kind === 'skin') SAVE.skin = id;

  saveUserData();
  return { ok: true, msg: '¡Comprado!' };
}

const DROP_TABLE_BASE = [
  { id: 'coins',  label: 'Monedas',        icon: '🪙', w: 46, color: '#ffd166' },
  { id: 'health', label: 'Orbe de vida',   icon: '💚', w: 16, color: '#5dff9a' },
  { id: 'energy', label: 'Orbe de energía',icon: '💠', w: 14, color: '#5ce1ff' },
  { id: 'power',  label: 'Potenciador',    icon: '⭐', w: 9,  color: '#ff9f43' },
  { id: 'gem',    label: 'Cristal premium',icon: '💎', w: 5,  color: '#c77dff' },
  { id: 'nothing',label: 'Nada',           icon: '·',  w: 10, color: '#5c7a6b' }
];

function dropChances() {
  const luck = SAVE.up.luck | 0;
  const table = DROP_TABLE_BASE.map(d => Object.assign({}, d));
  const gem = table.find(d => d.id === 'gem');
  const pow = table.find(d => d.id === 'power');
  const nothing = table.find(d => d.id === 'nothing');
  gem.w += luck * 1.6;
  pow.w += luck * 0.8;
  nothing.w = Math.max(0, nothing.w - luck * 1.8);
  const total = table.reduce((a, d) => a + d.w, 0);
  return table.map(d => Object.assign({}, d, { pct: (d.w / total) * 100 }));
}

/* Exponer para uso global */
window.SAVE = SAVE;
window.saveGame = saveGame;
window.saveUserData = saveUserData;
window.getCurrentUser = getCurrentUser;
window.getUserData = getUserData;
window.updateUserData = updateUserData;
window.registerUser = registerUser;
window.loginUser = loginUser;
window.logoutUser = logoutUser;
window.addFriend = addFriend;
window.removeFriend = removeFriend;
window.loadFriends = loadFriends;
window.USERS = USERS;
